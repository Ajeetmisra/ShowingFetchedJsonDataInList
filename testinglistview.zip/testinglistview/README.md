# testinglistview
### This is a sample app that will show (the covid19india live status of States) JSON data in the listview using custom Array Adapter and BackGround Thread.
![Screenshot (17)](https://user-images.githubusercontent.com/42707954/80278161-9a3b6900-8711-11ea-9c46-cd7c27bb26bb.png)
